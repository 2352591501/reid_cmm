fastreid.utils
========================

fastreid.utils.colormap module
--------------------------------

.. automodule:: fastreid.utils.colormap
    :members:
    :undoc-members:
    :show-inheritance:

fastreid.utils.comm module
----------------------------

.. automodule:: fastreid.utils.comm
    :members:
    :undoc-members:
    :show-inheritance:


fastreid.utils.events module
------------------------------

.. automodule:: fastreid.utils.events
    :members:
    :undoc-members:
    :show-inheritance:


fastreid.utils.logger module
------------------------------

.. automodule:: fastreid.utils.logger
    :members:
    :undoc-members:
    :show-inheritance:


fastreid.utils.registry module
--------------------------------

.. automodule:: fastreid.utils.registry
    :members:
    :undoc-members:
    :show-inheritance:

fastreid.utils.memory module
----------------------------------

.. automodule:: fastreid.utils.memory
    :members:
    :undoc-members:
    :show-inheritance:


fastreid.utils.analysis module
----------------------------------

.. automodule:: fastreid.utils.analysis
    :members:
    :undoc-members:
    :show-inheritance:


fastreid.utils.visualizer module
----------------------------------

.. automodule:: fastreid.utils.visualizer
    :members:
    :undoc-members:
    :show-inheritance:

fastreid.utils.video\_visualizer module
-----------------------------------------

.. automodule:: fastreid.utils.video_visualizer
    :members:
    :undoc-members:
    :show-inheritance:

